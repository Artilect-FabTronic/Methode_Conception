[ToucheLibre project](http://touchelibre.fr)

![Logo](http://touchelibre.fr/wp-content/uploads/2019/03/Icon_ToucheLibre_V3.png)

# Version Française

## Partie logiciel du clavier ToucheLibre


***************************

# English version

## Software part of ToucheLibre keyboard