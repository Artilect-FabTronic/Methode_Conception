[ToucheLibre project](http://touchelibre.fr)

![Logo](http://touchelibre.fr/wp-content/uploads/2019/03/Icon_ToucheLibre_V3.png)

# Version Française

## Partie électronique du clavier ToucheLibre


***************************

# English version

## Electronic part of ToucheLibre keyboard