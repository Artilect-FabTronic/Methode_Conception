[Site Web du Projet]()

# Nom du Projet

![Logo Projet]()

## Version Française

### Présentation du Projet

![Photo de l’objet]()

Le projet xxx a pour but…


### Les dossiers

Le dossier **00_Management** sert à l’équipe pour s’organiser et communiquer sur le projet. Le contenu n’a pas forcément vocation à être partagé au grand public.

Le dossier **01_Système** contient tous les éléments architecturant, la spécification générale du produit et toutes les informations qui consernent potentiellement tous les métiers

Les dossiers **02_ à 04_** servent à la conception du produit. Il contient toute l’étude et toutes les sources. Nous sommes organisés par métier. Ici on trouve la mécanique l’électronique, le logiciel, mais on pourrait en imaginer d’autres selon la nature du projet.

Le dossier **XX_Fabrication** est destiné à ceux qui veulent  simplement fabriquer le produit sans trop réfléchir au détail de la conception. Ce dossier est un peu l’équivalent de la rubrique «Téléchargement» pour un projet de type logiciel libre. Mais évidement, un objet libre ne se fabrique pas aussi facilement qu’un simple téléchargement. La philosophie de ce dossier est d’expliquer le plus simplement possible comment fabriquer l’objet.


### Comment Contribuer   ?


***************************

## English version

### Presentation of Project

### The Files

### How to Contribute    ?
