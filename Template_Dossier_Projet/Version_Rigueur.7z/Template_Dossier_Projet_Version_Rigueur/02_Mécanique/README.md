[ToucheLibre project](http://touchelibre.fr)

![Logo](http://touchelibre.fr/wp-content/uploads/2019/03/Icon_ToucheLibre_V3.png)

# Version Française

## Partie mécanique du clavier ToucheLibre


***************************

# English version

## Mechanical Part of ToucheLibre Keyboard